<!DOCTYPE html>
<html>
<head>
<title>Sticky Header and Footer</title>
<style type="text/css">
/* Reset body padding and margins */
body {
        background: url(images/krishna-bhagwat-gita.jpg) no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
}

/* Make Header Sticky */
#header_container {
	background:#eee;
	border:1px solid #666;
	height:73px;
	left:0;
	position:fixed;
	width:100%;
	top:0;
	z-index:auto;
}
#header{
	line-height:60px;
	width:100%;
	height:73px;
	text-align:left;
	margin-top: 0;
	margin-right: auto;
	margin-bottom: 0;
	margin-left: auto;
	background-color:#000000;
	
}


/* CSS for the content of page. I am giving top and bottom padding of 80px to make sure the header and footer do not overlap the content.*/
#container {
	overflow:auto;
	width:100%;
	margin-top: 0;
	margin-right: auto;
	margin-bottom: 0;
	margin-left: auto;
	padding-top: 80px;
	padding-right: 0;
	padding-bottom: 80px;
	padding-left: 0;
	
}
#content{}

/* Make Footer Sticky */
#footer_container {
	background:#eee;
	border:1px solid #666;
	bottom:0;
	height:60px;
	left:0;
	position:fixed;
	width:100%;
}
#footer {
	line-height:60px;
	background-color:#000000;
	width:100%;
	text-align:center;
	margin-top: 0;
	margin-right: auto;
	margin-bottom: 0;
	margin-left: auto;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>
<!-- BEGIN: Sticky Header -->
<div id="header_container">
	<div id="header"><a href="menu.php"><img src="images/icon_home.png" width="54" height="56" border="0" title="Back to Home" align="middle" {vertical-align: middle;}></a><img src="images/header.gif" width="899" height="73" align="middle" title="Vrinda Devi Information Center"></div>
</div>
<!-- END: Sticky Header -->
<!-- BEGIN: Page Content -->
<div id="container">
	<div id="content">