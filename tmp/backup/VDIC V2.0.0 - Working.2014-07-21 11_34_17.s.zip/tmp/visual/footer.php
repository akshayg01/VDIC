</div>
</div>
<!-- END: Page Content -->

<!-- BEGIN: Sticky Footer -->
<div id="footer_container">
<div id="footer"><font color="#00FFFF" face="Verdana, Arial, Helvetica, sans-serif">&copy; Vrindadevi Information Center. All Rights Reserved</font></div>
</div>
<!-- END: Sticky Footer -->
</body>
</html>